import React from 'react'
import Dashboard from './Dashboard'
import Header from './Header'

const page = () => {
  return (
    <div>
        <Header />
        <Dashboard />
    </div>
  )
}

export default page