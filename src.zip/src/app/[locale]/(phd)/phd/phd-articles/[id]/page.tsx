
import React from 'react'
import Scholarship from './Scholarship'
import CardComponent from './CardComponent';

const page = () => {
  return (
    <div>
        <Scholarship />
        <CardComponent />
    </div>
  )
}

export default page;