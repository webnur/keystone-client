import React from "react";

const page = () => {
  return <div>this is about page</div>;
};

export default page;
