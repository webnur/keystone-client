export enum tagTypes {
  user = "user",
  course = "course",
}

export const tagTypesList = [tagTypes.user, tagTypes.course];
