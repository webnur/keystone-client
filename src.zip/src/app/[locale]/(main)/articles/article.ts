export const articlesData = [
  {
    title: "How are PhD programs structured in the USA?",
    date: "Aug 16, 2024",
    image: "https://i.ibb.co.com/txH8qMm/ezgif-3-c99bcf9998.jpg",
  },
  {
    title: "Graduate Assistantship: Everything You Need to Know",
    date: "Aug 16, 2024",
    image: "https://i.ibb.co.com/txH8qMm/ezgif-3-c99bcf9998.jpg",
  },
  {
    title: "Can you get a PhD without a Master's?",
    date: "Aug 14, 2024",
    image: "https://i.ibb.co.com/txH8qMm/ezgif-3-c99bcf9998.jpg",
  },
  {
    title: "The Best Countries for Scientists",
    date: "Aug 8, 2024",
    image: "https://i.ibb.co.com/txH8qMm/ezgif-3-c99bcf9998.jpg",
  },
  {
    title: "Women Scholarship for International Students 2024",
    date: "April 2024",
    image: "https://i.ibb.co.com/txH8qMm/ezgif-3-c99bcf9998.jpg",
  },
  {
    title: "How Many Years Does it Take to Complete a PhD?",
    date: "April 2024",
    image: "https://i.ibb.co.com/txH8qMm/ezgif-3-c99bcf9998.jpg",
  },
  // Add more mock data as needed
];
