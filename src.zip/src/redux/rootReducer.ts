import { baseApi } from "./api/baseapi";

export const reducer = {
  [baseApi.reducerPath]: baseApi.reducer,
};
